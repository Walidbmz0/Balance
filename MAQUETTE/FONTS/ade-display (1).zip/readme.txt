Ade Display is a free serif font inspired by the aesthetics of the nineties. The horizontal serifs combined with the inside corner roundness give this font it's defining characteristic. 

Ade Display is a free for both personal & commercial use.
It's free, so feel free to use the tag #adetype in your future projects.

https://www.behance.net/studiothunder
https://www.instagram.com/itsthunderstudio/
https://thunder.rs/

